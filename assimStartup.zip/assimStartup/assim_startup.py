"""
/***************************************************************************
 assimStartup
                                 A QGIS plugin
 This plugin loads data required to begin the SNODAS Assimilation Process
                              -------------------
        begin                : 2016-08-16
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Shawn Carter / UCAR
        email                : shawn.carter@noaa.gov
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QFileInfo, Qt, QTimer
from PyQt4.QtGui import QAction, QIcon
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from assim_startup_dialog import assimStartupDialog
import os.path
import processing
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
import os, shutil


class assimStartup:

    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'assimStartup_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = assimStartupDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&SNODAS Assimilation Startup')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'assimStartup')
        self.toolbar.setObjectName(u'assimStartup')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('assimStartup', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/assimStartup/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Loads SNODAS Assimilation Layers'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&SNODAS Assimilation Startup'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def run(self):

        # Change these next three folders (First Time Run)
        sourceFolder = r'C:/Users/shawn.carter/Desktop/GIS_Files'
        workingFolder = r'C:/assimilation'
        symbologyFolder = r'C:/Users/shawn.carter/Documents/Assim/symbology'
        backgroundFolder = r'C:/Users/shawn.carter/Documents/Assim/common_layer/common_layer'
        
        iface.mapCanvas().refresh()

        vectorSymbology = os.path.join(symbologyFolder, 'shapefile')
        rasterSymbology = os.path.join(symbologyFolder, 'raster')
        vectorData = os.path.join(sourceFolder, 'point_data_shape')
        rasterData = os.path.join(sourceFolder, 'snow_line_raster')
        working_vectorData = os.path.join(workingFolder, 'point_data_shape')
        working_rasterData = os.path.join(workingFolder, 'snow_line_raster')

        

        """Run method that performs all plugin actions"""
        keep_old_layers_values = ['No', 'Yes']
        self.dlg.keep_layers_input.addItems(keep_old_layers_values) # Values for the drop-down menu in the plugin

        # show the dialog
        result = self.dlg.exec_()
        if result == 1:
            start_date = self.dlg.start_date_input.text()
            end_date = self.dlg.end_date_input.text()
            keep_old_layers = self.dlg.keep_layers_input.currentIndex()

        # See if OK is pushed 
        if result:

            # Setting up our map canvas (and especially the layer groupings)
            root = QgsProject.instance().layerTreeRoot()
            baseMapsGroup = root.insertGroup(0, 'Base Map Layers')
            analysisGroup = root.insertGroup(0, 'Remote Sensing and Analysis')
            snodasGroup   = root.insertGroup(0, 'SNODAS Developed Rasters')
            nwmGroup      = root.insertGroup(0, 'National Water Model Data')

            # Set the visibility of the groups and whether they should be collapsed or not.
            baseMapsGroup.setExpanded(False)
            analysisGroup.setExpanded(False)
            analysisGroup.setVisible(Qt.Unchecked)
            snodasGroup.setExpanded(False)
            snodasGroup.setVisible(Qt.Unchecked)
            nwmGroup.setExpanded(False)
            nwmGroup.setVisible(Qt.Unchecked)
            
            # Clear all layers from the map
            if keep_old_layers == 0:
                QgsMessageLog.logMessage('Clearing the map of old layers......', 'Assimilation Startup')
                QgsMapLayerRegistry.instance().removeAllMapLayers()
                self.iface.mapCanvas().refresh()



            ################################################################################################
            #                                   LOAD THE BASE LAYERS                                       #
            ################################################################################################

            QgsMessageLog.logMessage('Loading the Base Layers......', 'Assimilation Startup')
            dem_file       = os.path.join(backgroundFolder, 'SRTM_elevation_average.tif')
            hillshade_file = os.path.join(backgroundFolder, 'hillshading.tif')
            polygons_file  = os.path.join(backgroundFolder, 'bound_p.shp')

            # Create the Qgis Layers
            polygons  = QgsVectorLayer(polygons_file, 'Water/Land', 'ogr')
            QgsMapLayerRegistry.instance().addMapLayer(polygons, False)
            
            dem       = QgsRasterLayer(dem_file, 'SRTM DEM')
            QgsMapLayerRegistry.instance().addMapLayer(dem, False)
            
            hillshade = QgsRasterLayer(hillshade_file, 'Hillshade')
            QgsMapLayerRegistry.instance().addMapLayer(hillshade, False)

            # Add the Layers to the Base Map Layer Group
            polygons_node   = QgsLayerTreeLayer(polygons)
            dem_node        = QgsLayerTreeLayer(dem)
            hillshade_node  = QgsLayerTreeLayer(hillshade)

            baseMapsGroup.addChildNode(polygons_node)
            baseMapsGroup.addChildNode(dem_node)
            baseMapsGroup.addChildNode(hillshade_node)

            # Style the base map layers
            polygons.loadNamedStyle(os.path.join(vectorSymbology, 'polybkgrd.qml'))
            dem.loadNamedStyle(os.path.join(rasterSymbology, 'demStyle.qml'))
            hillshade.loadNamedStyle(os.path.join(rasterSymbology, 'hillshadeStyle.qml'))

            ##################################################################################################
            #                     LOAD THE REMOTE SENSING AND NATIONAL WATER MODEL DATA                      #
            ##################################################################################################

            QgsMessageLog.logMessage('Near Real Time remotely sensed data and national water model data loading......', 'Assimilation Startup')

            dtg = '%s-%s-%s' % (end_date[:4], end_date[4:6], end_date[6:8])

            """ This creates an xml statement that retrieves the satellite data from NASA GIBS server """
            GIBS_layers = {'AMSR2_Snow_Water_Equivalent': ['2km', '.png', '5', '4'],
                'GMI_Snow_Rate_Asc' : ['2km', '.png', '5', '4'],
                'GMI_Snow_Rate_Dsc' : ['2km', '.png', '5', '4'],
                'MODIS_Aqua_Snow_Cover' : ['500m', '.png', '7', '4'],
                'MODIS_Terra_Snow_Cover' : ['500m', '.png', '7', '4'],
                'SMAP_L4_Snow_Mass' : ['2km', '.png', '5', '4']}

            for layer in GIBS_layers:
                xml_statement = '<GDAL_WMS><Service name="TMS"><ServerUrl>http://gibs.earthdata.nasa.gov/wmts/epsg4326' + \
                    '/best/%s/default/%s/%s/${z}/${y}/${x}%s</ServerUrl></Service><DataWindow><UpperLeftX>-180.0</UpperLeftX>' % (layer, dtg, GIBS_layers[layer][0], GIBS_layers[layer][1] ) +\
                    '<UpperLeftY>90</UpperLeftY><LowerRightX>396.0</LowerRightX><LowerRightY>-198</LowerRightY>' +\
                    '<TileLevel>%s</TileLevel><TileCountX>2</TileCountX><TileCountY>1</TileCountY><YOrigin>top</YOrigin>'  %( GIBS_layers[layer][2])+ \
                    '</DataWindow><Projection>EPSG:4326</Projection><BlockSizeX>512</BlockSizeX><BlockSizeY>512</BlockSizeY>' +\
                    '<BandsCount>%s</BandsCount></GDAL_WMS>' % (GIBS_layers[layer][3] )

                raster = QgsRasterLayer(xml_statement, layer)
                QgsMapLayerRegistry.instance().addMapLayer(raster, False)

                raster_node = QgsLayerTreeLayer(raster)
                analysisGroup.addChildNode(raster_node)

                # Turn off this layer to avoid cluttering the map
                analysisGroup.setVisible(Qt.Unchecked)

            ###################################################################################################
            #                                LOAD THE SNODAS RASTERS                                          #
            ###################################################################################################
            
            rasters = {'SWE_%s05.tif' % end_date[:-2] : [os.path.join(rasterSymbology, 'swe.qml')],
                'SC_SWE_%s05.tif' % end_date[:-2]: [os.path.join(rasterSymbology, 'SC_SWE_Master.qml')],
                'SC_NESDIS_%s.tif' % start_date[:-2]: [os.path.join(rasterSymbology, 'SC_NESDIS_master.qml')]}

            for raster in rasters:
                # Copy Raster to the working directory
                if os.path.isfile(os.path.join(rasterData, raster)):
                    shutil.copy(os.path.join(rasterData, raster), working_rasterData)
                    QgsMessageLog.logMessage('Copying %s to the working directory: %s' % (raster, working_rasterData), 'Assimilation Startup')

                    # Load the copied rasters into the map document
                    rasterFileName = os.path.join(working_rasterData, raster)
                    rasterInfo = QFileInfo(rasterFileName)
                    rasterBaseName = rasterInfo.baseName()

                    rasterLayer = QgsRasterLayer(rasterFileName, rasterInfo.baseName())
                    rasterLayer.loadNamedStyle(rasters[raster][0])

                    QgsMapLayerRegistry.instance().addMapLayer(rasterLayer, False)
                    raster_node = QgsLayerTreeLayer(rasterLayer)
                    snodasGroup.addChildNode(raster_node)

                    QgsMessageLog.logMessage('%s loaded into the map document......' % rasterInfo.baseName(), 'Assimilation Startup')

                else:
                    QgsMessageLog.logMessage('%s does not exist, you will have to manually load it!!!!!!!!' % rasterInfo.baseName(), 'Assimilation Startup')


            #######################################################################################################
            #                          LOAD THE NATIONAL WATER MODEL DATA RESULTS                                 #
            #######################################################################################################

            nwm_rasters = {'SNOWH_%s_WGS84.tif' % end_date[:-2] : os.path.join(rasterSymbology, 'snowH_style.qml'),
                'SNOWT_AVG_%s_WGS84.tif' % end_date[:-2]        : os.path.join(rasterSymbology, 'snowT_style.qml'),
                'SOILSAT_TOP_%s_WGS84.tif' % end_date[:-2]      : os.path.join(rasterSymbology, 'soilsat_style.qml'),
                'FSNO_%s_WGS84.tif' % end_date[:-2]             : os.path.join(rasterSymbology, 'fsno_style.qml')}

            for raster in nwm_rasters:
                # Copy Raster to the working directory
                if os.path.isfile(os.path.join(rasterData, raster)):
                    shutil.copy(os.path.join(rasterData, raster), working_rasterData)
                    QgsMessageLog.logMessage('Copying %s to the working directory: %s' % (raster, working_rasterData), 'Assimilation Startup')

                    # Load the copied rasters into the map document
                    rasterFileName = os.path.join(working_rasterData, raster)
                    rasterInfo = QFileInfo(rasterFileName)
                    rasterBaseName = rasterInfo.baseName()

                    rasterLayer = QgsRasterLayer(rasterFileName, rasterInfo.baseName())
                    rasterLayer.loadNamedStyle(nwm_rasters[raster])

                    QgsMapLayerRegistry.instance().addMapLayer(rasterLayer, False)
                    raster_node = QgsLayerTreeLayer(rasterLayer)
                    nwmGroup.addChildNode(raster_node)

                    QgsMessageLog.logMessage('%s loaded into the map document......' % rasterInfo.baseName(), 'Assimilation Startup')

                else:
                    QgsMessageLog.logMessage('%s does not exist, you will have to manually load it!!!!!!!!' % rasterInfo.baseName(), 'Assimilation Startup')


            ######################################################################################################
            #                              LOAD THE DELTA POINTS SHAPEFILE                                       #
            ######################################################################################################

            deltaSHP = 'ssm1054_md_based_%s_%s.shp' % (start_date, end_date)
            if os.path.isfile(os.path.join(vectorData, deltaSHP)):
                for file in os.listdir(vectorData):
                    if file.startswith(deltaSHP[:-4]):
                        shutil.copy(os.path.join(vectorData, file), working_vectorData)
                        QgsMessageLog.logMessage('Copying %s to the working directory %s' % (file, working_vectorData), 'Assimilation Startup')

                # Load the delta points shapefile into the map document
                deltaSHP_file = os.path.join(working_vectorData, deltaSHP)
                deltaLayer = QgsVectorLayer(deltaSHP_file, 'Delta Points %s' % end_date, 'ogr')
                deltaLayer.loadNamedStyle(os.path.join(vectorSymbology, 'point_delta_style.qml'))

                QgsMapLayerRegistry.instance().addMapLayer(deltaLayer, True)
               
            else:
                QgsMessageLog.logMessage('ssm1054_md_based_%s_%s.shp does not exist!!!!!!!' % (start_date, end_date), 'Assimilation Startup')



            #######################################################################################################
            #                           CENTER THE MAP ON A HIGH DELTA VALUE                                      #
            #######################################################################################################

            # We will find the feature with the greatest absolute difference between observed and modeled SWE and center the map on that feature
            features = deltaLayer.getFeatures()
            deltas = []
            f = features.next()
            fields = [c.name() for c in f.fields().toList()]
            for position, item in enumerate(fields):
                if item == 'D_SWE_OM':
                    attributeNumber = position # This loop avoids hard-coding where the D_SWE_OM field is located (future proofing)

            for feature in features:
                deltas.append(feature[attributeNumber]) # Create a list of D_SWE_Values

            maxDelta = abs(max(deltas))
            processing.runalg("qgis:selectbyexpression", 'Delta Points %s' % end_date, '"D_SWE_OM" = %s' % maxDelta, 0) # Select the feature with the largest error

            selected_features = deltaLayer.selectedFeatures()
            i = 0
            for feature in selected_features:
                i += 1
                QgsMessageLog.logMessage('Counted %s features with the max delta in modeled and observed SWE......' % i, 'Assimilation Startup')
                geom = feature.geometry().asPoint() 

            processing.runalg("qgis:selectbyexpression", 'Delta Points %s' % end_date, '"D_SWE_OM" = %s' % maxDelta, 2) # de-selct the feature

            left = geom[0] - 1
            upper = geom[1] + 1
            right = geom[0] + 1
            lower = geom[1] -1     # We'll use these values to creata 1 degree by 1 degree box to center our map

            newExtent = QgsRectangle(left, lower, right, upper)
            self.iface.mapCanvas().setCenter(geom)
            self.iface.mapCanvas().setExtent(newExtent)



