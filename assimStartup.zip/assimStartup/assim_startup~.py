# -*- coding: utf-8 -*-
"""
/***************************************************************************
 assimStartup
                                 A QGIS plugin
 This plugin loads data required to begin the SNODAS Assimilation Process
                              -------------------
        begin                : 2016-08-16
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Shawn Carter / UCAR
        email                : shawn.carter@noaa.gov
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication, QFileInfo, Qt, QTimer
from PyQt4.QtGui import QAction, QIcon
# Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from assim_startup_dialog import assimStartupDialog
import os.path
import processing
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
import os, shutil


class assimStartup:

    # Change these next three folders (First Time Run)
    sourceFolder = r'C:/Users/shawn.carter/Desktop/GIS_Files'
    workingFolder = r'C:/assimilation'
    symbologyFolder = r'C:/Users/shawn.carter/Documents/Assim/symbology'
    backgroundFolder = r'C:/Users/shawn.carter/Documents/Assim/common_layer/common_layer'
    
    iface.mapCanvas().refresh()

    vectorSymbology = os.path.join(symbologyFolder, 'shapefile')
    rasterSymbology = os.path.join(symbologyFolder, 'raster')
    vectorData = os.path.join(sourceFolder, 'point_data_shape')
    rasterData = os.path.join(sourceFolder, 'snow_line_raster')
    working_vectorData = os.path.join(workingFolder, 'point_data_shape')
    working_rasterData = os.path.join(workingFolder, 'snow_line_raster')

    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'assimStartup_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = assimStartupDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&SNODAS Assimilation Startup')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'assimStartup')
        self.toolbar.setObjectName(u'assimStartup')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('assimStartup', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/assimStartup/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Loads SNODAS Assimilation Layers'),
            callback=self.run,
            parent=self.iface.mainWindow())


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&SNODAS Assimilation Startup'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def clearTheMap(self):
        """Clears the Map"""
        QgsMessageLog.logMessage('Clearing the map of old layers......', 'Assimilation Startup')
        QgsMapLayerRegistry.instance().removeAllMapLayers()
        
        self.iface.mapCanvas().refresh()
    
    def loadDeltaPoints(self, start_date, end_date):
        # Copy the delta points shapefile to the working directory
        
        deltaSHP = 'ssm1054_md_based_%s_%s.shp' % (start_date, end_date)
        if os.path.isfile(os.path.join(self.vectorData, deltaSHP)):
            for file in os.listdir(self.vectorData):
                if file.startswith(deltaSHP[:-4]):
                   # QgsMessageLog.logMessage('Copying %s to the working directory: %s' %(deltaSHP, self.working_vectorData))
                    shutil.copy(os.path.join(self.vectorData, file), self.working_vectorData)

            # Load the delta points shapefile into the map document
            deltaSHP_file = os.path.join(self.working_vectorData, deltaSHP)
            deltaLayer = QgsVectorLayer(deltaSHP_file, 'Delta Points', 'ogr')
            deltaLayer.loadNamedStyle(os.path.join(self.vectorSymbology, 'point_delta_style.qml'))
            QgsMapLayerRegistry.instance().addMapLayer(deltaLayer)
            self.iface.zoomToActiveLayer()

            QgsMessageLog.logMessage('%s loaded into the map document......' % deltaSHP, 'Assimilation Startup')


        else:
            QgsMessageLog.logMessage('ssm1054_md_based_%s_%s.shp does not exist!' % (start_date, end_date), 'Assimilation Startup')

        return deltaLayer     


    def centerMap(self, deltaLayer):
        # The section will find the feature with the greatest difference between observed and modeled SWE (we'll center the map on that)
        features = deltaLayer.getFeatures()
        deltas = []
        f = features.next()
        fields = [c.name() for c in f.fields().toList()]
        for position, item in enumerate(fields):
            if item == 'D_SWE_OM':
                attributeNumber = position  #this loop avoids hard-coding where the D_SWE_OM field is located (future-proofing)

        for feature in features:
            deltas.append(feature[attributeNumber]) # Create a list of D_SWE_OM values

        maxDelta = abs(max(deltas)) # Find the biggest absolute error between observed and modeled SWE
        QgsMessageLog.logMessage('Max Delta is %s ......' % round(maxDelta,4), 'Assimilation Startup')
        processing.runalg("qgis:selectbyexpression", 'Delta Points', '"D_SWE_OM" = %s' % maxDelta, 0) # select the feature with the largest error

        selected_features = deltaLayer.selectedFeatures()
        i=0
        for feature in selected_features:
            i += 1
            QgsMessageLog.logMessage('Counted %s features ......' % i, 'Assimilation Startup')
            geom = feature.geometry().asPoint() # layer.selectedFeatures() is a iterator object, so it has to looped even though there is only one feature selected

        processing.runalg("qgis:selectbyexpression", 'Delta Points', '"D_SWE_OM" = %s' % maxDelta, 2) # de-select the feature
        left = geom[0] + 1
        upper = geom[1] + 1
        right = geom[0] - 1
        lower = geom[1] - 1 # This will create a 1 degree by 1 degree box to center our map

        newExtent = QgsRectangle(left, lower, right, upper)
        QgsMessageLog.logMessage('Extent should be: %s %s %s %s .......' %(left, lower, right, upper), 'Assimilation Startup')
        #self.iface.mapCanvas().setCenter(geom)
        self.iface.mapCanvas().setCenter(geom)
        self.iface.mapCanvas().setExtent(newExtent)
            
    def loadRasters(self, raster, rasterStyle):
        # Copy shapefiles to the working directory
        if os.path.isfile(os.path.join(self.rasterData, raster)):
            for file in os.listdir(self.rasterData):
                if file.startswith(raster):
                    shutil.copy(os.path.join(self.rasterData, file), self.working_rasterData)
                    QgsMessageLog.logMessage('Copying %s to the working directory: %s' % (file, self.working_rasterData), 'Assimilation Startup')

            # Load the rasters into the map document
            rasterFileName = os.path.join(self.working_rasterData, raster)
            rasterInfo = QFileInfo(rasterFileName)
            rasterBaseName = rasterInfo.baseName()
            
            rasterLayer = QgsRasterLayer(rasterFileName, rasterBaseName)
            rasterLayer.loadNamedStyle(rasterStyle)
            
            QgsMapLayerRegistry.instance().addMapLayer(rasterLayer)
            QgsMessageLog.logMessage('%s loaded into the map document.' % rasterInfo.baseName(), 'Assimilation Startup')
        
        else:
            QgsMessageLog.logMessage('%s does not exist, you will have manually load it!' % (raster), 'Assimilation Startup')

    def loadBaseLayers(self):
        # Location of Background Layer Files
        QgsMessageLog.logMessage('Loading the Base Layers.......', 'Assimilation Startup')
        dem_file = os.path.join(self.backgroundFolder, 'SRTM_elevation_average.tif')
        hillshade_file = os.path.join(self.backgroundFolder, 'hillshading.tif')
        polygons_file = os.path.join(self.backgroundFolder, 'bound_p.shp')
        lines_file = os.path.join(self.backgroundFolder, 'bound_l.shp')
        
        # Create the Qgis Layers
        
        polygons = QgsVectorLayer(polygons_file, 'Water/Land', 'ogr')
        QgsMapLayerRegistry.instance().addMapLayer(polygons)
        lines = QgsVectorLayer(lines_file, 'Borders', 'ogr')
        QgsMapLayerRegistry.instance().addMapLayer(lines)
        dem = QgsRasterLayer(dem_file, 'SRTM DEM')
        QgsMapLayerRegistry.instance().addMapLayer(dem)
        hillshade = QgsRasterLayer(hillshade_file, 'Hillshade')
        QgsMapLayerRegistry.instance().addMapLayer(hillshade)
        
        # Define symbology
        QgsMessageLog.logMessage('Stylizing the Base Layers .........')
        polygons.loadNamedStyle(os.path.join(self.vectorSymbology, 'polybkgrd.qml'))
        lines.loadNamedStyle(os.path.join(self.vectorSymbology, 'linebkrd.qml'))
        dem.loadNamedStyle(os.path.join(self.rasterSymbology, 'demStyle.qml'))
        hillshade.loadNamedStyle(os.path.join(self.rasterSymbology, 'hillshadeStyle.qml'))

    def loadGIBRemoteSensing(self, date):
        QgsMessageLog.logMessage('NRT Remotely Sensed Data....', 'Assimilation Startup')

        dtg = date[:4] + '-' + date[4:6] + '-' + date[6:8]
        
        # This creates an XML statement that retrieves satellite data from NASA GIBS server
        GIBS_Layers = {'AMSR2_Snow_Water_Equivalent':['2km', '.png', '5', '4'], 
            'GMI_Snow_Rate_Asc':['2km', '.png', '5', '4'],
            'GMI_Snow_Rate_Dsc':['2km', '.png', '5', '4'],
            'MODIS_Aqua_Snow_Cover': ['500m', '.png', '7', '4'],
            'MODIS_Terra_Snow_Cover': ['500m', '.png', '7', '4'],
            'SMAP_L4_Snow_Mass': ['2km', '.png', '5', '4'],
            }

        for layer in GIBS_Layers:
            xml_statement = '<GDAL_WMS><Service name="TMS"><ServerUrl>http://gibs.earthdata.nasa.gov/wmts/epsg4326' + \
                '/best/%s/default/%s/%s/${z}/${y}/${x}%s</ServerUrl></Service><DataWindow><UpperLeftX>-180.0</UpperLeftX>' % (layer, dtg, GIBS_Layers[layer][0], GIBS_Layers[layer][1] ) +\
                '<UpperLeftY>90</UpperLeftY><LowerRightX>396.0</LowerRightX><LowerRightY>-198</LowerRightY>' +\
                '<TileLevel>%s</TileLevel><TileCountX>2</TileCountX><TileCountY>1</TileCountY><YOrigin>top</YOrigin>'  %( GIBS_Layers[layer][2])+ \
                '</DataWindow><Projection>EPSG:4326</Projection><BlockSizeX>512</BlockSizeX><BlockSizeY>512</BlockSizeY>' +\
                '<BandsCount>%s</BandsCount></GDAL_WMS>' % (GIBS_Layers[layer][3] )
            raster = QgsRasterLayer(xml_statement, layer)
            QgsMapLayerRegistry.instance().addMapLayer(raster)
            # Turn off Layers (Avoids Cluttering the Map)
            legend = iface.legendInterface()
            legend.setLayerVisible(raster, False)

    def run(self):
        """Run method that performs all the real work"""
        self.iface.mapCanvas().refresh()
        keep_old_layers_values = ['No', 'Yes']
        self.dlg.keep_layers_input.addItems(keep_old_layers_values)

        keep_old_layers = 'no'
        # show the dialog
        self.dlg.show()

        # Run the dialog event loop
        result = self.dlg.exec_()
        if result == 1:
            start_date = self.dlg.start_date_input.text()
            end_date   = self.dlg.end_date_input.text()
            keep_old_layers = self.dlg.keep_layers_input.currentIndex()

        # See if OK was pressed
        if result:
            rasters = {'SWE_%s05.tif' % end_date[:-2]:[os.path.join(self.rasterSymbology,'swe.qml'), 'SWE_*'],
                'SC_SWE_%s05.tif' % end_date[:-2]: [os.path.join(self.rasterSymbology,'SC_SWE_Master.qml'), 'SC_SWE_*'],
                'SC_NESDIS_%s.tif' % end_date[:-2]: [os.path.join(self.rasterSymbology, 'SC_NESDIS_Master.qml'), 'SC_NES*']}
    
            if keep_old_layers == 0:
                self.clearTheMap()
    
            self.loadBaseLayers()

            self.loadGIBRemoteSensing(start_date)
    
            for raster in rasters:
                self.loadRasters(raster, rasters[raster][0])
    
            self.loadDeltaPoints(start_date, end_date)
            
            QgsMessageLog.logMessage('SNODAS Assimilation Preparation Complete......', 'Assimilation Startup')
